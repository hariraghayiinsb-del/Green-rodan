# Green Roodan

ساختار:
- index.html
- assets/css/style.css
- assets/js/app.js

نکته:
- تصاویر از Unsplash لود می‌شوند.
- ورود OTP و پرداخت آگهی در نسخه فعلی به API واقعی نیاز دارند.
- endpoint پرداخت در `assets/js/app.js` برابر `/api/payments/ad-fee` است.
